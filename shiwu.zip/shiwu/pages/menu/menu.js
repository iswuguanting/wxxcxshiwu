Page({
    data: {
        category: [
            {name:'水果',id:'guowei'},
            {name:'蔬菜',id:'shucai'},
            {name:'小炒',id:'chaohuo'},
            {name:'点心',id:'dianxin'},
            {name:'香茶',id:'cucha'},
            {name:'淡饭',id:'danfan'}
        ],
        detail:[],
        curIndex: 0,
        isScroll: false,
        toView: 'guowei'
    },
    onReady(){
        var self = this;
        wx.request({
            success(res){
                self.setData({
                    detail : res.data
                })
            }
        });
    },
    switchTab(e){
      const self = this;
      this.setData({
        isScroll: true
      })
      setTimeout(function(){
        self.setData({
          toView: e.target.dataset.id,
          curIndex: e.target.dataset.index
        })
      },0)
      setTimeout(function () {
        self.setData({
          isScroll: false
        })
      },1)
        
    }
    
})