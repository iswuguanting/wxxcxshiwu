
Page({
  data: {
    category: [{
        id: "37",
        parentId: "1005",
        img: "/images/wu.png",
        name: '早餐'
      },
      {
        id: "38",
        parentId: "1005",
        img: "/images/zao.png",
        name: '午餐'
      },
      {
        id: "39",
        parentId: "1005",
        img: "/images/xiawu.png",
        name: '下午茶'
      },
      {
        id: "40",
        parentId: "1005",
        img: "/images/wan.png",
        name: '晚餐'
      },
      {
        id: "41",
        parentId: "1005",
        img: "/images/ye.png",
        name: '夜宵'
      }
    ]
  },

  

})