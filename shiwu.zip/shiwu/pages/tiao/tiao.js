// pages/tiao/tiao.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        creatt: [{
            name: '外'
        }, {
            name: '卖'
        }, {
            name: '订'
        }, {
            name: '单'
        }, {
            name: '查'
        }, {
            name: '询'
        }],
        com: [ '美团外卖', '饿了么'], // 用于显示在页面中的快递名称
        no: null, // 运单号
    company: ['mtwm',"elm"], // 传递给快递查询接口的值
    index: 0, // 用户选择的快递公司的数组索引
    expressInfo: null, // 查询到的物流信息
    },
    
    search:function(){
        wx.request({
          url: 'http://127.0.0.1:3000/search?com='+this.data.company[this.data.index]+"&no="+this.data.no,
          method:'GET',
          header: {
            'content-type': 'application/json' // 默认值
            },
            header:{
              'content-type':'application/json'
            },
            success:(res)=>{
              this.setData({
                expressInfo:res.data
              })
            }
        })
      }, 
       noInput:function(e){
        this.setData({
          no:e.detail.value
        })
      },
    companyInput: function (e) {
        this.setData({
            index: e.detail.value
        })
    },/**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})