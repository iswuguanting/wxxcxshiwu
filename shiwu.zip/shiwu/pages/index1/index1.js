Page({

    /**
     * 页面的初始数据
     */
    data: {
        category: [{
                id: "66",
                parentId: "1006",
                img: "/images/iconone.png",
                name: '待付款'
            },
            {
                id: "77",
                parentId: "1007",
                img: "/images/icontwo.png",
                name: '已退款'
            },
            {
                id: "88",
                parentId: "1008",
                img: "/images/iconthree.png",
                name: '全部订单'
            }
        ],
        canIUse: wx.canIUse('button.open-type.getUserInfo')

    },
    goDetail: function (e) {
        wx.navigateTo({
            url: `/pages/detail/detail?id=${e.currentTarget.dataset.id}`,
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    
        onLoad: function() {
            // 查看是否授权
            wx.getSetting({
              success (res){
                if (res.authSetting['scope.userInfo']) {
                  // 已经授权，可以直接调用 getUserInfo 获取头像昵称
                  wx.getUserInfo({
                    success: function(res) {
                      console.log(res.userInfo)
                    }
                  })
                }
              }
            })
          
    },

    onGetUserInfo: function (e) {
        this.setData({
            logged: true,
            avatarUrl: e.detail.userInfo.avatarUrl,
            username: e.detail.userInfo.nickName,
        })
    },
    tiaozhuan: function (e) {
        wx.navigateTo({
            url: '/pages/tiao/tiao',
          })
    },
    phone: function(e){
        wx.makePhoneCall({
          phoneNumber: '1008611',
        })
    }
})